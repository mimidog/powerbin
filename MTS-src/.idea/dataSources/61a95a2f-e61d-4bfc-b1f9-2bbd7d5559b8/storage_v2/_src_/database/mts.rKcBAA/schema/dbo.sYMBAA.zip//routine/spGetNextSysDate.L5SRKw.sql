CREATE FUNCTION [dbo].[spGetNextSysDate](@SUB_ID   VARCHAR(1),   --子系统编号
                                         @SYS_DATE VARCHAR(8))   --系统日期
 RETURNS VARCHAR(8) 
 /*----------------------------------------
 功能：得到指定日期的下一交易日

 select dbo.spGetNextSysDate(1,'20181026')
 *--------------------------------------*/
AS
BEGIN
DECLARE @NEXT_DATE VARCHAR(8) 

  SELECT @NEXT_DATE=MIN(PHYSICAL_DATE)
   FROM T_CALENDAR
   WHERE TRD_DATE_FLAG='1'
      AND PHYSICAL_DATE-@SYS_DATE>0

 	  RETURN(@NEXT_DATE);
END
go

