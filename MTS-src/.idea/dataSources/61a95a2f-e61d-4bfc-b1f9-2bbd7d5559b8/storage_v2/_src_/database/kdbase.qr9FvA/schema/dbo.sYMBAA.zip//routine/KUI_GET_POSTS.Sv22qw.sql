


--1. 创建处理函数  
CREATE FUNCTION [dbo].[KUI_GET_POSTS](@id bigint)  
RETURNS varchar(8000)  
AS  
BEGIN  
    DECLARE @str varchar(8000)  
    SET @str = ''  
	SELECT @str = @str + ',' + convert(varchar,P.POST_ID)
  FROM UUM_OPER_POST P
 WHERE P.USER_CODE = @id
    RETURN STUFF(@str, 1, 1, '')  
END



go

