CREATE  FUNCTION [dbo].[spGetTradeDayProfit] (@OP_ID               VARCHAR(20) , ---交易员代码 
                                              @CUACCT_ID           VARCHAR(20) , ---资金代码 
                                              @SYS_DATE            VARCHAR(8))    ---日期 
/*---------------------------------
功能:得到交易员在指定日期盈余

select dbo.spGetTradeDayProfit('6101004','','20181009')
 
-----------------------------*/

RETURNS NUMERIC(19,4) 

AS

BEGIN
 DECLARE @Profit  NUMERIC(19,4) 
   
   SET  @Profit=0   

   SELECT @Profit=SUM(ACCT_PROFIT)
   FROM  T_TRADE_DAY_INFO
   WHERE (ISNULL(@OP_ID,'')='' OR OP_ID=@OP_ID)
       AND (ISNULL(@CUACCT_ID,'')='' OR CUACCT_ID=@CUACCT_ID)
       AND (ISNULL(@SYS_DATE,'')='' OR SYS_DATE=@SYS_DATE)
 

 
	  RETURN(@Profit);
END

go

