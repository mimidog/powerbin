CREATE PROC [dbo].[proTradeDaySumClear]  
/*----------------------------------------------
功能：交易员每日日终清算
例:
DECLARE @ERR_ID    VARCHAR(8),@ERR_MSG   VARCHAR(64)
EXEC proTradeDaySumClear '20181025',@ERR_ID out ,@ERR_MSG out
select @ERR_ID,@ERR_MSG

*---------------------------------------------*/
AS
  SET  NOCOUNT ON 
  DECLARE @SYS_DATE  VARCHAR(8),@OP_ID varchar(12)
   SELECT @SYS_DATE=dbo.spGetSysDate('1')
    
     DECLARE CURSOR_OP_ID CURSOR FOR  
     SELECT OP_ID FROM T_FUND_INFO_SUB
   
   OPEN CURSOR_OP_ID  
      FETCH NEXT FROM CURSOR_OP_ID INTO  @OP_ID
    WHILE @@FETCH_STATUS = 0
    BEGIN 
	    EXEC  proTradeRealTimeInfo @OP_ID,'1'
        FETCH NEXT FROM CURSOR_OP_ID INTO @OP_ID
    END
  CLOSE CURSOR_OP_ID  
  DEALLOCATE CURSOR_OP_ID   

-------------------------------------------------------------------计算未分配--
   DECLARE @HOLD_MAKET_VAL        numeric(19,4),  --持仓市值
        @FUND_BAL               numeric(19,4),  --资金余额
		@CALLOT_IN_FUND         numeric(19,4),  --初始资金
		@FUND_AVL               numeric(19,4),  --资金可用
		@FUND_TRD_FRZ           numeric(19,4),  --冻结资金
		@MAKET_PROFIT           numeric(19,4),  --持仓盈余
		@TOTAL_COST             numeric(19,4),   --费用汇总
		@O_ID                   varchar(12) ,
		@CUACCT_ID               varchar(12) 
		 
 
 SELECT @FUND_BAL=0,
        @FUND_AVL=0,
		@FUND_TRD_FRZ=0,
        @CALLOT_IN_FUND=0 

      SELECT @HOLD_MAKET_VAL=SUM(INST_BAL*dbo.spGetStkPrice(INST_ID)),
            @MAKET_PROFIT=SUM( INST_BAL*(dbo.spGetStkPrice(INST_ID)-COST_PRICE)),
	    	@CUACCT_ID=CUACCT_ID,@O_ID=''
      FROM T_MTS_ASSET   WHERE UNUSE_AMOUNT>0
      GROUP BY CUACCT_ID

	  DELETE FROM T_TRADE_DAY_INFO WHERE CUACCT_ID=@CUACCT_ID AND OP_ID=''
 	  INSERT INTO T_TRADE_DAY_INFO
	  SELECT @O_ID,@CUACCT_ID,
	    CALLOT_IN_FUND=round(@CALLOT_IN_FUND*1.0/10000,2),                       --初始资金
        TOTAL_FUND=round(@FUND_BAL*1.0/10000+@HOLD_MAKET_VAL*1.0/10000,2),                   --总资产=资金余额+总市值
		ACCT_PROFIT=round(@FUND_BAL*1.0/10000+@HOLD_MAKET_VAL*1.0/10000,2)-round(@CALLOT_IN_FUND*1.0/10000,2), --账户盈余=总资产-初始资金
		HOLD_MAKET_VAL=round(@HOLD_MAKET_VAL*1.0/10000*1.0/10000,2),                         --总市值
		MAKET_PROFIT=round(@MAKET_PROFIT*1.0/10000,2),                             --持仓盈余
		FUND_BAL=round(@FUND_BAL*1.0/10000,2),
		FUND_AVL=round(@FUND_AVL*1.0/10000,2),
		FUND_TRD_FRZ=round(@FUND_TRD_FRZ*1.0/10000,2),
		TOTAL_COST=@TOTAL_COST,
		@SYS_DATE


		SET  NOCOUNT OFF
go

