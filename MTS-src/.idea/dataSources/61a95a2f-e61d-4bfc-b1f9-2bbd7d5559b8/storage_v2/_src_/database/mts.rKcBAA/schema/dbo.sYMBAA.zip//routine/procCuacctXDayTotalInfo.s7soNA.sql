CREATE PROC [dbo].[procCuacctXDayTotalInfo]   @CUACCT_ID  VARCHAR(8),
                                              @TYPE   VARCHAR(1),  --0:总资产，1:总盈余，2：总市值 3:资金余额
                                              @S_DATE VARCHAR(8),
											  @E_DATE VARCHAR(8)
/*----------------------------------------------------------
功能：客户指定天数内的综合信息查询
exec procCuacctXDayTotalInfo ' ',1,20181021,20181031 
*-----------------------------------------------------------*/
AS
 SET NOCOUNT ON 
     SET @TYPE=ISNULL(@TYPE,0) 
	 DECLARE @I INT 
	 SELECT @I=(SELECT PHYSICAL_NUM
		    FROM (SELECT TRD_DATE_FLAG,PHYSICAL_DATE,Row_Number() OVER (ORDER BY PHYSICAL_DATE ) AS PHYSICAL_NUM
                 FROM T_CALENDAR 
				 WHERE TRD_DATE_FLAG='1') D 
	       WHERE  D.PHYSICAL_DATE=@E_DATE)
		   -(SELECT PHYSICAL_NUM
		    FROM (SELECT TRD_DATE_FLAG,PHYSICAL_DATE,Row_Number() OVER (ORDER BY PHYSICAL_DATE ) AS PHYSICAL_NUM
                 FROM T_CALENDAR 
				 WHERE TRD_DATE_FLAG='1') E
	       WHERE  E.PHYSICAL_DATE=@S_DATE)
     SELECT @I=ISNULL(@I,1) 

	 if @CUACCT_ID=''
	 select @CUACCT_ID= ''''''''''

	 DECLARE @SQL_DECLARE VARCHAR(8000), 
	         @SQL_EXEC VARCHAR(8000),@SQL VARCHAR(8000),
	         @DAY_SQL VARCHAR(8000) 
	 SELECT @SQL_DECLARE='DECLARE ',
	        @SQL_EXEC='DECLARE @SQL VARCHAR(8000) SELECT  @SQL='''+'SELECT ' + @CUACCT_ID +' AS CUACCT_ID, ',
	        @DAY_SQL='SELECT  ' 
		
		WHILE @I>0
		BEGIN
		  SELECT @SQL_DECLARE=@SQL_DECLARE+'@PRO_DAY'+CONVERT(CHAR(2),@I)+' VARCHAR(8),' 
		  SELECT @DAY_SQL=@DAY_SQL+'@PRO_DAY'+CONVERT(CHAR(2),@I)+'='+'dbo.spGetSDaySysDate(1,'+@E_DATE+','+RTRIM(CONVERT(CHAR(2),@I))+'),'     
		  IF @TYPE=0
	    BEGIN
		        SELECT @SQL_EXEC=@SQL_EXEC+'ISNULL(dbo.spGetTradeDayTotalFund('''+''''+''''+''''+','+@CUACCT_ID+','+''''+'+'+'@PRO_DAY'+RTRIM(CONVERT(CHAR(2),@I))+'+'+''''+'),0) ''+''[''+@PRO_DAY'+RTRIM(CONVERT(CHAR(2),@I))+'+'''+']'+','
		    END 
			  ELSE IF @TYPE=1 
			  BEGIN
				 SELECT @SQL_EXEC=@SQL_EXEC+'ISNULL(dbo.spGetTradeDayProfit('''+''''+''''+''''+','+@CUACCT_ID+','+''''+'+'+'@PRO_DAY'+RTRIM(CONVERT(CHAR(2),@I))+'+'+''''+'),0) ''+''[''+@PRO_DAY'+RTRIM(CONVERT(CHAR(2),@I))+'+'''+']'+','
			  END
			    ELSE IF @TYPE=2 
			  BEGIN
				 SELECT @SQL_EXEC=@SQL_EXEC+'ISNULL(dbo.spGetTradeDayMaketVal('''+''''+''''+''''+','+@CUACCT_ID+','+''''+'+'+'@PRO_DAY'+RTRIM(CONVERT(CHAR(2),@I))+'+'+''''+'),0) ''+''[''+@PRO_DAY'+RTRIM(CONVERT(CHAR(2),@I))+'+'''+']'+','
			  END
			     ELSE IF @TYPE=3
			  BEGIN
				 SELECT @SQL_EXEC=@SQL_EXEC+'ISNULL(dbo.spGetTradeDayFundAvl('''+''''+''''+''''+','+@CUACCT_ID+','+''''+'+'+'@PRO_DAY'+RTRIM(CONVERT(CHAR(2),@I))+'+'+''''+'),0) ''+''[''+@PRO_DAY'+RTRIM(CONVERT(CHAR(2),@I))+'+'''+']'+','
			  END
		  SELECT @I=@I-1 
		END 
		 SELECT @SQL=left(@SQL_DECLARE,len(@SQL_DECLARE)-1)
		             + left(@DAY_SQL,len(@DAY_SQL)-1)  
					 + left(@SQL_EXEC,len(@SQL_EXEC)-1)+'''' 
					-- + 'select @SQL' 
					 + 'EXEC(@SQL)' 
		 EXEC(@SQL)
		  
SET NOCOUNT ON
go

