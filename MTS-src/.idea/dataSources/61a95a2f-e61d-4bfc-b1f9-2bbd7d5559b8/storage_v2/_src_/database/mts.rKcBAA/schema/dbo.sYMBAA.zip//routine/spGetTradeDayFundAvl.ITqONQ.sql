CREATE  FUNCTION [dbo].[spGetTradeDayFundAvl]    (@OP_ID               VARCHAR(20) , ---交易员代码 
                                                 @CUACCT_ID           VARCHAR(20) , ---资金代码 
                                                 @SYS_DATE            VARCHAR(8))    ---日期 
/*---------------------------------
功能:得到交易员在指定日期资金余额

select dbo.spGetTradeDayMaketVal('6101004','','20181024')
 
 SELECT * FROM T_TRADE_DAY_INFO
-----------------------------*/

RETURNS NUMERIC(19,4) 

AS

BEGIN
 DECLARE @FundAvl  NUMERIC(19,4) 
   
   SET  @FundAvl=0   

   SELECT @FundAvl=ISNULL(SUM(FUND_AVL),0)
   FROM  T_TRADE_DAY_INFO
   WHERE (ISNULL(@OP_ID,'')='' OR OP_ID=@OP_ID)
       AND (ISNULL(@CUACCT_ID,'')='' OR CUACCT_ID=@CUACCT_ID)
       AND (ISNULL(@SYS_DATE,'')='' OR SYS_DATE=@SYS_DATE)
 

 
	  RETURN(@FundAvl);
END

go

