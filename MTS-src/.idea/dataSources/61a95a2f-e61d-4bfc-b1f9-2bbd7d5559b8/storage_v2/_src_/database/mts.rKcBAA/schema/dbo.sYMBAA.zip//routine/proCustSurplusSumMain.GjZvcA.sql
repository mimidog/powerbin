CREATE PROC [dbo].[proCustSurplusSumMain]     @LOGIN_OP_ID   varchar(12)            --当前登录柜员 
as
/*------------------------------------------------------------------
说明: 账户盈亏汇总查询
 proCustSurplusSumMain '8888' 
*-----------------------------------------------------------------*/
 SET NOCOUNT ON 
 
   DECLARE @SYS_DATE VARCHAR(8),@PRE_DATE VARCHAR(8)
   SELECT  @SYS_DATE=dbo.spGetSysDate('1') ,                     --得到当前系统的系统日期
           @PRE_DATE=dbo.spGetPreSysDate('1',@SYS_DATE)          --得到当前系统的上一日系统日期

 if exists(select top 1 1 from sys.objects where name='#tmp' and type='U')
 begin 
   drop table #CustSurplusSumMain  
 end
  CREATE TABLE #CustSurplusSumMain(
   CUST_ID                 varchar(12) , 
   CUACCT_ID               varchar(12) , 
   OP_ID                   varchar(12) , 
   STK_ID                  varchar(10) , 
   BUY_AMT                 numeric(19,4) ,
   BUY_QTY                 numeric(19,0) ,
   BUY_COST                numeric(19,4) ,
   SELL_AMT                numeric(19,4) ,
   SELL_QTY                numeric(19,0) ,
   SELL_COST               numeric(19,4) ,
   COST_AMT                numeric(19,4) ,
   PROC_COST               numeric(19,4) ,
   STAMP_TAX               numeric(19,4) ,
   T_TYPE                  int , 
   ABS_QTY                 numeric(19,0) ,
   NOW_PRICE               numeric(19,4), 
   TODAY_SALE_PROFIT       numeric(19,4), 
   TODAY_FLOAT_PROFIT      numeric(19,4))  

INSERT INTO #CustSurplusSumMain exec procTradeStkMatchInfo '','','',@LOGIN_OP_ID,''

SELECT   
               SUM(CALLOT_AMT)                AS CALLOT_AMT,                --入金总额  
               SUM(USE_AMOUNT)                AS HAVE_CFG_FUND,             --已配置资产
               SUM(UNUSE_AMOUNT)              AS UNHAVE_CFG_FUND,           --未配置资产
               SUM(ACCT_NUM)                  AS ACCT_NUM,                  --账户数量  
               SUM(YEST_PROFIT)               AS YEST_PROFIT,               --前日盈亏     
               SUM(TOTAL_FUND)                AS TOTAL_FUND,                --资产汇总  
               SUM(HOLD_MAKET_VAL)            AS HOLD_MAKET_VAL,            --持仓市值  
               SUM(FUND_BAL)                  AS FUND_BAL,                  --现金余额  
               SUM(TODAY_SALE_PROFIT)         AS TODAY_SALE_PROFIT,         --当日买卖盈
               SUM(TODAY_FLOAT_PROFIT)        AS TODAY_FLOAT_PROFIT,        --当日浮动盈
               SUM(TODAY_SUM_PROFIT)          AS TODAY_SUM_PROFIT,          --当日盈亏汇总
               SUM(CALLOT_IN_AMT)             AS CALLOT_IN_AMT,             --入金汇总  
               SUM(CALLOT_OUT_AMT)            AS CALLOT_OUT_AMT,            --出金汇总  
               SUM(BUY_AMT)                   AS BUY_AMT,                   --买入金额汇
               SUM(SELL_AMT)                  AS SELL_AMT,                  --卖出金额汇
               SUM(PROC_COST_SUM)             AS PROC_COST_SUM,             --佣金汇总  
               SUM(STAMP_TAX_SUM)             AS STAMP_TAX_SUM              --印花税汇总
FROM (

     SELECT   T.CUST_ID,  
              CALLOT_AMT                                                             AS CALLOT_AMT,              --入金总额
             (ISNULL(USE_AMOUNT,0))                                                  AS USE_AMOUNT,              --已配置资产
             (ISNULL(UNUSE_AMOUNT,0))                                                AS UNUSE_AMOUNT,            --未配置资产
		      ROUND(ACCT_NUM,0)                                                      AS ACCT_NUM, 
			  (ISNULL(YEST_PROFIT,0))                                                YEST_PROFIT,               --账户数量
			 -- ISNULL(HOLD_MAKET_VAL,0)+ ISNULL(FUND_BAL,0)-  (ISNULL(USE_AMOUNT,0))  AS YEST_PROFIT,          --前日盈亏
		      ISNULL(HOLD_MAKET_VAL,0)+ ISNULL(FUND_BAL,0)                           AS TOTAL_FUND,              --资产汇总
		      ISNULL(HOLD_MAKET_VAL,0)                                               AS HOLD_MAKET_VAL,          --持仓市值
		      ISNULL(FUND_BAL,0)                                                     AS FUND_BAL,                --现金余额
		      ISNULL(TODAY_SALE_PROFIT,0)                                            AS TODAY_SALE_PROFIT,       --当日买卖盈亏
		      ISNULL(TODAY_FLOAT_PROFIT,0)                                           AS TODAY_FLOAT_PROFIT,      --当日浮动盈亏
		      ISNULL(TODAY_SUM_PROFIT,0)                                             AS TODAY_SUM_PROFIT,        --当日盈亏汇总
		      ISNULL(CALLOT_IN_AMT,0)                                                AS CALLOT_IN_AMT,           --入金汇总
		      ISNULL(CALLOT_OUT_AMT,0)                                               AS CALLOT_OUT_AMT,          --出金汇总
		     (ISNULL(BUY_AMT,0))                                                     AS BUY_AMT,                 --买入金额汇总
		     (ISNULL(SELL_AMT,0))                                                    AS SELL_AMT,                --卖出金额汇总
		     (ISNULL(PROC_COST,0))                                                   AS PROC_COST_SUM,           --佣金汇总
		     (ISNULL(STAMP_TAX,0))                                                   AS STAMP_TAX_SUM            --印花税汇总
 FROM 
 ( 
  SELECT   A.CUST_ID,CUACCT_ID,
           ISNULL(UNUSE_AMOUNT,0)                                                  AS UNUSE_AMOUNT,           --未配置资产
           CALLOT_IN_FUND-CALLOT_OUT_FUND                                          AS CALLOT_AMT,              --入金总额
           ISNULL(dbo.spGetTradeDayProfit('',A.CUACCT_ID,@PRE_DATE),0)*10000       AS YEST_PROFIT,
		   dbo.spGetCALLOT_AMT('',A.CUACCT_ID,0,'3')                               AS USE_AMOUNT,              --已配置资产
		   dbo.spGetCUACCT_SUBQTY(A.CUACCT_ID)                                     AS ACCT_NUM,                --账户数量 
		   FUND_BAL                                                                AS FUND_BAL,                --现金余额
 		   CALLOT_IN_FUND                                                          AS CALLOT_IN_AMT,           --入金汇总
		   CALLOT_OUT_FUND                                                         AS CALLOT_OUT_AMT           --出金汇总 
 FROM  T_FUND_INFO A , T_CUSTOMER C
 WHERE A.CUST_ID=C.CUST_ID 
   AND (ISNULL(@LOGIN_OP_ID,'')='' OR dbo.spIsOperOrg(@LOGIN_OP_ID,C.ORG_CODE)=1)
) T 


  LEFT JOIN (
             SELECT Y1.CUST_ID, SUM(ISNULL(Y.INST_BAL,0)*dbo.spGetStkPrice(Y.INST_ID)) AS HOLD_MAKET_VAL
			 FROM T_MTS_ASSET  Y,T_TRDACCT Y1 
			 WHERE Y.CUST_ID=Y1.CUST_ID
				  AND Y.TRDACCT=Y1.TRDACCT 
		     GROUP BY Y1.CUST_ID)  M
    ON T.CUST_ID=M.CUST_ID

 LEFT JOIN 
 (
   SELECT 
      CUST_ID,BUY_AMT=SUM(BUY_AMT),SELL_AMT=SUM(SELL_AMT),PROC_COST=SUM(PROC_COST), 
	  OTHER_COST=SUM(PROC_COST),
	  TODAY_SALE_PROFIT=SUM(TODAY_SALE_PROFIT),
	  TODAY_FLOAT_PROFIT=SUM(TODAY_FLOAT_PROFIT),
	  TODAY_SUM_PROFIT=SUM(TODAY_SALE_PROFIT+TODAY_FLOAT_PROFIT),
	  STAMP_TAX=SUM(STAMP_TAX)
   FROM (
         SELECT CUST_ID,CUACCT_ID,OP_ID,STK_ID,BUY_AMT,BUY_QTY,BUY_COST,SELL_AMT,SELL_QTY,SELL_COST,
	            COST_AMT,PROC_COST,STAMP_TAX,T_TYPE,ABS_QTY,NOW_PRICE,
			    TODAY_SALE_PROFIT,TODAY_FLOAT_PROFIT
          FROM #CustSurplusSumMain  ) AS C
    GROUP BY CUST_ID
  )   S
    ON  T.CUST_ID=S.CUST_ID
) CS
go

