CREATE FUNCTION [dbo].[spGetPreSysDate] (@SUB_ID   VARCHAR(1),   --子系统编号
                                         @SYS_DATE VARCHAR(8))   --系统日期
 RETURNS VARCHAR(8) 
 /*----------------------------------------
 功能：得到指定日期的前一交易日

 select dbo.spGetPreSysDate(1,'20181029')
 *--------------------------------------*/
AS
BEGIN
DECLARE @PRE_DATE VARCHAR(8) 

  SELECT @PRE_DATE=MAX(PHYSICAL_DATE)
   FROM T_CALENDAR
   WHERE TRD_DATE_FLAG='1'
      AND PHYSICAL_DATE-@SYS_DATE<0

 	  RETURN(@PRE_DATE);
END
go

