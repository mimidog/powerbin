CREATE PROC [dbo].[proCustSurplusSumDetail]     @LOGIN_OP_ID   varchar(12)            --当前登录柜员 
as
/*------------------------------------------------------------------
说明: 账户盈亏汇总明细查询
 proCustSurplusSumDetail '8888'

 select *from T_FUND_INFO
*-----------------------------------------------------------------*/
 SET NOCOUNT ON 

 DECLARE @SYS_DATE VARCHAR(8),@PRE_DATE VARCHAR(8)
 SELECT  @SYS_DATE=dbo.spGetSysDate('1') ,                     --得到当前系统的系统日期
         @PRE_DATE=dbo.spGetPreSysDate('1',@SYS_DATE)          --得到当前系统的上一日系统日期


 if exists(select top 1 1 from sys.objects where name='#tmp' and type='U')
 begin 
   drop table #CustSurplusSumDetail  
 end
  CREATE TABLE #CustSurplusSumDetail(
   CUST_ID                 varchar(12) , 
   CUACCT_ID               varchar(12) , 
   OP_ID                   varchar(12) , 
   STK_ID                  varchar(10) , 
   BUY_AMT                 numeric(19,4) ,
   BUY_QTY                 numeric(19,0) ,
   BUY_COST                numeric(19,4) ,
   SELL_AMT                numeric(19,4) ,
   SELL_QTY                numeric(19,0) ,
   SELL_COST               numeric(19,4) ,
   COST_AMT                numeric(19,4) ,
   PROC_COST               numeric(19,4) ,
   STAMP_TAX               numeric(19,4) ,
   T_TYPE                  int , 
   ABS_QTY                 numeric(19,0) ,
   NOW_PRICE               numeric(19,4), 
   TODAY_SALE_PROFIT       numeric(19,4), 
   TODAY_FLOAT_PROFIT      numeric(19,4))  

INSERT INTO #CustSurplusSumDetail exec procTradeStkMatchInfo '','','',@LOGIN_OP_ID,''
    
 SELECT         A.CUST_ID,dbo.spGetCustName(A.CUST_ID)                                    AS  CUST_NAME,
                A.CUACCT_ID,
			    CALLOT_IN_FUND-CALLOT_OUT_FUND                                            AS CALLOT_AMT ,
				dbo.spGetCALLOT_AMT('',A.CUACCT_ID,0,'3')                                 AS HAVE_CFG_FUND,
				CALLOT_IN_FUND-CALLOT_OUT_FUND-dbo.spGetCALLOT_AMT('',A.CUACCT_ID,0,'3')  AS UNHAVE_CFG_FUND,
				dbo.spGetCUACCT_SUBQTY(A.CUACCT_ID)                                       AS  ACCT_NUM,
                A.FUND_BAL,(ISNULL(K.HOLD_MAKET_VAL,0)+A.FUND_BAL)                        AS TOTAL_FUND,
                ISNULL(dbo.spGetTradeDayProfit('',A.CUACCT_ID,@PRE_DATE),0)*10000         AS YEST_PROFIT,---
                ISNULL(K.HOLD_MAKET_VAL,0)                                                AS HOLD_MAKET_VAL,
                dbo.spGetCALLOT_AMT('',A.CUACCT_ID,@SYS_DATE,'2')                         AS CALLOT_IN_AMT,
				dbo.spGetCALLOT_AMT('',A.CUACCT_ID,@SYS_DATE,'1')                         AS CALLOT_OUT_AMT,
                 ISNULL(BUY_AMT,0)                                                        AS BUY_INST_AMT_SUM,
				 ISNULL(SELL_AMT,0)                                                       AS SELL_INST_AMT_SUM,
                 ISNULL(PROC_COST,0)                                                      AS PROC_COST_SUM,
				 ISNULL(STAMP_TAX,0)                                                      AS STAMP_TAX_SUM,
                 ISNULL(T.TODAY_SALE_PROFIT,0)                                            AS TODAY_SALE_PROFIT,
				 ISNULL(T.TODAY_FLOAT_PROFIT,0)                                           AS TODAY_FLOAT_PROFIT,
				 ISNULL(T.TODAY_SALE_PROFIT,0)+ISNULL(T.TODAY_FLOAT_PROFIT,0)             AS TODAY_SUM_PROFIT,
				 dbo.spGetSysDate('1')                                                    AS UP_DATE
   FROM 
		   (SELECT T.CUST_ID,CUACCT_ID,FUND_BAL,CALLOT_IN_FUND,CALLOT_OUT_FUND
		    FROM T_FUND_INFO T ,T_CUSTOMER C
			WHERE T.CUST_ID=C.CUST_ID  
		 	 AND (ISNULL(@LOGIN_OP_ID,'')='' OR dbo.spIsOperOrg(@LOGIN_OP_ID,C.ORG_CODE)=1)
			) A
		  
    LEFT JOIN
			 (  SELECT Y1.CUST_ID, SUM(ISNULL(Y.INST_BAL,0)*dbo.spGetStkPrice(Y.INST_ID)) AS HOLD_MAKET_VAL
			 FROM T_MTS_ASSET  Y,T_TRDACCT Y1 
			 WHERE Y.CUST_ID=Y1.CUST_ID
				  AND Y.TRDACCT=Y1.TRDACCT 
		     GROUP BY Y1.CUST_ID) K
			   ON  A.CUST_ID=K.CUST_ID 

      LEFT JOIN
			  (
			   
        SELECT CUST_ID,CUACCT_ID ,
               BUY_QTY=SUM(BUY_QTY),
	           PROC_COST=SUM(PROC_COST),
	           STAMP_TAX=SUM(STAMP_TAX),
	           BUY_AMT=SUM(BUY_AMT),
	           SELL_AMT=SUM(SELL_AMT),
               TODAY_SALE_PROFIT=SUM(TODAY_SALE_PROFIT),
	           TODAY_FLOAT_PROFIT=SUM(TODAY_FLOAT_PROFIT)
        FROM 
           ( SELECT CUST_ID,CUACCT_ID,OP_ID,STK_ID,BUY_AMT,BUY_QTY,BUY_COST,SELL_AMT,SELL_QTY,SELL_COST,COST_AMT,PROC_COST,STAMP_TAX,T_TYPE,ABS_QTY,NOW_PRICE,TODAY_SALE_PROFIT,TODAY_FLOAT_PROFIT
             FROM #CustSurplusSumDetail   )   T1
        GROUP BY  CUST_ID,CUACCT_ID 
   
     )  
			  T
     ON A.CUST_ID=T.CUST_ID AND A.CUACCT_ID=T.CUACCT_ID 
	 
drop table #CustSurplusSumDetail 

 SET NOCOUNT OFF
go

