CREATE FUNCTION spGetTraderSellOmsQty( @OP_ID			VARCHAR(20),    ---交易员代码
								  @CUST_ID			VARCHAR(32),    ---客户代码	
								  @CUACCT_ID		VARCHAR(32),    ---资金账号
								  @TRDACCT			VARCHAR(32),	---交易账号
								  @STK_ID			VARCHAR(8))		---证券代码
/*---------------------------------
功能:得到交易员已经下单信号(未交易)指定证券的订单数量

-----------------------------*/
RETURNS NUMERIC(19,0)
AS
BEGIN
		DECLARE @SELL_OMS_QTY NUMERIC(19,0);

		SELECT @SELL_OMS_QTY=isnull(SUM(OMS_QTY),0)
		FROM T_OMS
		WHERE  CUST_ID=@CUST_ID AND CUACCT_ID=@CUACCT_ID AND TRDACCT=@TRDACCT
				AND OP_ID=@OP_ID AND STK_ID=@STK_ID
				AND  TRADE_DIRECT='2' AND OMS_STATUS='0' AND ORDER_LVL='1'
				AND OMS_DATE=(SELECT SYSTEM_DATE FROM T_SYS_CONTROL)


		RETURN(@SELL_OMS_QTY);
END


go

