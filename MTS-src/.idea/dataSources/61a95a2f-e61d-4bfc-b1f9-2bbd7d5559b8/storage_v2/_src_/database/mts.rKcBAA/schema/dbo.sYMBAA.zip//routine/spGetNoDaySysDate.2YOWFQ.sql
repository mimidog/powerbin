CREATE FUNCTION [dbo].[spGetNoDaySysDate] (@SUB_ID   VARCHAR(1),   --子系统编号
                                           @I  int)   --天数
 RETURNS VARCHAR(4) 
 /*----------------------------------------
 功能：得到指定天数的前一交易日

 select dbo.spGetNoDaySysDate(1,28) 
 *--------------------------------------*/
AS
BEGIN
DECLARE @SYS_DATE VARCHAR(8),@N_DATE VARCHAR(8)
  SELECT @SYS_DATE=dbo.spGetSysDate('1')

  SELECT @N_DATE=right(PHYSICAL_DATE,4)
  FROM 
   (
      SELECT TRD_DATE_FLAG,PHYSICAL_DATE,Row_Number() OVER (ORDER BY PHYSICAL_DATE ) AS PHYSICAL_NUM
      FROM T_CALENDAR WHERE TRD_DATE_FLAG='1' 
    ) C  
  WHERE  
     C.PHYSICAL_NUM=(
           SELECT PHYSICAL_NUM
		    FROM (SELECT TRD_DATE_FLAG,PHYSICAL_DATE,Row_Number() OVER (ORDER BY PHYSICAL_DATE ) AS PHYSICAL_NUM
                 FROM T_CALENDAR 
				 WHERE TRD_DATE_FLAG='1') D 
	       WHERE  D.PHYSICAL_DATE=dbo.spGetSysDate('1')
	             )-@I


 	  RETURN(@N_DATE);
END

go

