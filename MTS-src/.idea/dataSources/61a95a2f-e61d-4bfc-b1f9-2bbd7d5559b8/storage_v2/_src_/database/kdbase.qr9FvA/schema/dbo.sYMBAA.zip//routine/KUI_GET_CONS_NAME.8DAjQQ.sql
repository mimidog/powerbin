

--1. 创建处理函数  
create FUNCTION [dbo].[KUI_GET_CONS_NAME](@id int)  
RETURNS varchar(8000)  
AS  
BEGIN  
    DECLARE @str varchar(8000)  
    SET @str = ''  
	SELECT @str = @str + ',' + CONS_NAME
    FROM UUM_PERMISSION UP, UPM_PERM_CONS UPC, UUM_CONSTRAINTS C
   WHERE UPC.PERM_ID = UP.PERM_ID
     AND C.CONS_ID = UPC.CONS_ID
     AND UP.PERM_ID = @id
     AND C.CONS_STATE = 1;
    RETURN STUFF(@str, 1, 1, '')  
END



go

