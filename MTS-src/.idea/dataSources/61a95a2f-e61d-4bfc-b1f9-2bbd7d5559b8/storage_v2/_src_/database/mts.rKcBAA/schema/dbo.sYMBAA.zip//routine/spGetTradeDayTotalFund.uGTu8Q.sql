CREATE  FUNCTION [dbo].spGetTradeDayTotalFund      (@OP_ID               VARCHAR(20) , ---交易员代码 
                                                   @CUACCT_ID           VARCHAR(20) , ---资金代码 
                                                   @SYS_DATE            VARCHAR(8))    ---日期 
/*---------------------------------
功能:得到交易员在指定日期资产

select dbo.spGetTradeDayTotalFund('61010104','','20181025') 
SELECT *FROM T_TRADE_DAY_INFO
-----------------------------*/

RETURNS NUMERIC(19,4) 

AS

BEGIN
 DECLARE @TOTAL_FUND  NUMERIC(19,4) 
   
   SET  @TOTAL_FUND=0   

   SELECT @TOTAL_FUND=ISNULL(SUM(TOTAL_FUND),0)
   FROM  T_TRADE_DAY_INFO
   WHERE (ISNULL(@OP_ID,'')='' OR OP_ID=@OP_ID)
       AND (ISNULL(@CUACCT_ID,'')='' OR CUACCT_ID=@CUACCT_ID)
       AND (ISNULL(@SYS_DATE,'')='' OR SYS_DATE=@SYS_DATE)
 

 
	  RETURN(@TOTAL_FUND);
END

go

