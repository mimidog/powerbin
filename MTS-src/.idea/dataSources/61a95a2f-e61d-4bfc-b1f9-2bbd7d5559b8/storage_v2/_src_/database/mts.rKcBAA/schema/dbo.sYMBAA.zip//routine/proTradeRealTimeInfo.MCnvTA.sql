CREATE PROC [dbo].[proTradeRealTimeInfo] @OP_ID varchar(12),
                                         @OP_TYPE varchar(1) --0：实时查询 1：日终更新数据
/*--------------------------------------
功能：交易员实时综合信息

proTradeRealTimeInfo '6101004','1'
SELECT *FROM T_TRADE_DAY_INFO

select *from  T_FUND_INFO_SUB
*-------------------------------------*/
AS
SET NOCOUNT ON 
 DECLARE @HOLD_MAKET_VAL        numeric(19,4),  --持仓市值
        @FUND_BAL               numeric(19,4),  --资金余额
		@CALLOT_IN_FUND         numeric(19,4),  --初始资金
		@FUND_AVL               numeric(19,4),  --资金可用
		@FUND_TRD_FRZ           numeric(19,4),  --冻结资金
		@MAKET_PROFIT           numeric(19,4),  --持仓盈余
		@TOTAL_COST             numeric(19,4),   --费用汇总
		@CUACCT_ID               varchar(12),
		@SYS_DATE               varchar(8)

 SELECT @SYS_DATE=dbo.spGetSysDate('1')
 
 SELECT @FUND_BAL=FUND_BAL,
        @FUND_AVL=FUND_AVL,
		@FUND_TRD_FRZ=FUND_TRD_FRZ,
        @CALLOT_IN_FUND=CALLOT_IN_FUND,
		@CUACCT_ID=CUACCT_ID
  FROM T_FUND_INFO_SUB  WHERE OP_ID=@OP_ID

 SELECT @HOLD_MAKET_VAL=SUM(INST_BAL*dbo.spGetStkPrice(INST_ID)),
        @MAKET_PROFIT=SUM( INST_BAL*(dbo.spGetStkPrice(INST_ID)-COST_PRICE))
 FROM T_MTS_ASSET_SUB WHERE  OP_ID=@OP_ID


 SELECT @TOTAL_COST=SUM(TOTAL_COST) FROM T_TRADE_DAY_CLEAR_SUM  WHERE TRADE_ID=@OP_ID

 IF ISNULL(@OP_TYPE,'0')='0'
 BEGIN 

 SELECT CALLOT_OUT_FUND=isnull(@CALLOT_IN_FUND,0),                                           --初始资金
        TOTAL_FUND=isnull(@FUND_BAL,0)+isnull(@HOLD_MAKET_VAL,0),                            --总资产=资金余额+总市值
		ACCT_PROFIT=isnull(@FUND_BAL,0)+isnull(@HOLD_MAKET_VAL,0)-isnull(@CALLOT_IN_FUND,0), --账户盈余=总资产-初始资金
		HOLD_MAKET_VAL=isnull(@HOLD_MAKET_VAL,0),                                            --总市值
		MAKET_PROFIT=isnull(@MAKET_PROFIT,0),                                                --持仓盈余
		FUND_BAL=isnull(@FUND_BAL,0),
		FUND_AVL=isnull(@FUND_AVL,0),
		FUND_TRD_FRZ=isnull(@FUND_TRD_FRZ,0),
		TOTAL_COST=isnull(@TOTAL_COST,0)
END 
  ELSE 
    BEGIN 
      DELETE FROM T_TRADE_DAY_INFO WHERE SYS_DATE=@SYS_DATE AND OP_ID=@OP_ID
	  
	  INSERT INTO T_TRADE_DAY_INFO
	  SELECT @OP_ID,@CUACCT_ID,
	    CALLOT_IN_FUND=round(isnull(@CALLOT_IN_FUND,0)*1.0/10000,2),                                           --初始资金
        TOTAL_FUND=round(isnull(@FUND_BAL,0)*1.0/10000+isnull(@HOLD_MAKET_VAL,0)*1.0/10000,2),                           --总资产=资金余额+总市值
		ACCT_PROFIT=round(isnull(@FUND_BAL,0)*1.0/10000+isnull(@HOLD_MAKET_VAL,0)*1.0/10000,2)-round(isnull(@CALLOT_IN_FUND,0)*1.0/10000,2), --账户盈余=总资产-初始资金
		HOLD_MAKET_VAL=round(isnull(@HOLD_MAKET_VAL,0)*1.0/10000,2),                                           --总市值
		MAKET_PROFIT=round(isnull(@MAKET_PROFIT,0)*1.0/10000,2),                                               --持仓盈余
		FUND_BAL=round(isnull(@FUND_BAL,0)*1.0/10000,2),
		FUND_AVL=round(isnull(@FUND_AVL,0)*1.0/10000,2),
		FUND_TRD_FRZ=round(isnull(@FUND_TRD_FRZ,0)*1.0/10000,2),
		TOTAL_COST=@TOTAL_COST,
		@SYS_DATE

  END
SET NOCOUNT OFF
go

