CREATE  FUNCTION [dbo].[spGetSDaySysDate] (@SUB_ID   VARCHAR(1),   --子系统编号
                                             @DATE     VARCHAR(8),
                                             @I  int)   --天数
 RETURNS VARCHAR(8) 
 /*----------------------------------------
 功能：得到指定天数的前一交易日 
 select dbo.spGetNoUDaySysDate(1,20181010,1) 
 *--------------------------------------*/
AS
BEGIN
DECLARE  @N_DATE VARCHAR(8) 

  SELECT @N_DATE=PHYSICAL_DATE
  FROM 
   (
      SELECT TRD_DATE_FLAG,PHYSICAL_DATE,Row_Number() OVER (ORDER BY PHYSICAL_DATE ) AS PHYSICAL_NUM
      FROM T_CALENDAR WHERE TRD_DATE_FLAG='1' 
    ) C  
  WHERE  
     C.PHYSICAL_NUM=(
           SELECT PHYSICAL_NUM
		    FROM (SELECT TRD_DATE_FLAG,PHYSICAL_DATE,Row_Number() OVER (ORDER BY PHYSICAL_DATE ) AS PHYSICAL_NUM
                 FROM T_CALENDAR 
				 WHERE TRD_DATE_FLAG='1') D 
	        WHERE  D.PHYSICAL_DATE=@DATE
	             )-@I


 	  RETURN(@N_DATE);
END

go

