
--1. 创建处理函数  
CREATE FUNCTION [dbo].[KUI_GET_CONS](@id int)  
RETURNS varchar(8000)  
AS  
BEGIN  
    DECLARE @str varchar(8000)  
    SET @str = ''  
	SELECT @str = @str + ',' + convert(varchar,UPC.CONS_ID)
  FROM UUM_PERMISSION UP, UPM_PERM_CONS UPC, UUM_CONSTRAINTS UC
 WHERE UPC.PERM_ID = UP.PERM_ID
     AND UP.PERM_ID = @id
     AND UC.CONS_ID = UPC.CONS_ID
     AND UC.CONS_STATE = '1'
    RETURN STUFF(@str, 1, 1, '')  
END



go

