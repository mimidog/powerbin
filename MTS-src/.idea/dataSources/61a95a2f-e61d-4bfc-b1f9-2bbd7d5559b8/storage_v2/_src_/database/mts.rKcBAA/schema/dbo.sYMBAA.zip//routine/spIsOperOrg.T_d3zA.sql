
CREATE FUNCTION  spIsOperOrg    (@OP_ID VARCHAR(12),
                                  @ORG_CODE VARCHAR(12))
  RETURNS  int
  /*-------------------------------
  功能:判断操作员能否有访问该机构的权限
  
  select dbo.spIsOperOrg('81010001','8102') 
  *--------------------------------*/
AS
BEGIN
 
 
 DECLARE @IS_FLAG int, @ORG_LVL VARCHAR(32)  
  
  SET @IS_FLAG=0
 
  SELECT @ORG_LVL=ORG_LVL
  FROM kdbase..UUM_USER U,kdbase..UPM_ORG O
  WHERE U.ORG_CODE=O.ORG_CODE 
    AND U.USER_CODE=@OP_ID

  IF EXISTS(
     select TOP 1 1 
	  FROM kdbase..UPM_ORG 
	  WHERE ORG_CODE=@ORG_CODE  AND  CHARINDEX(@ORG_LVL,ORG_LVL)>0
	  )
   BEGIN 
	   SELECT @IS_FLAG=1
   END 

	  RETURN(@IS_FLAG);
END
go

