CREATE FUNCTION [dbo].[spGetOperName] (@OP_ID VARCHAR(20)) 
/*---------------------------------


-----------------------------*/

    RETURNS VARCHAR(32) 
AS
BEGIN
 DECLARE @OP_NAME VARCHAR(32)

select  @OP_NAME=''   

select @OP_NAME=isnull(USER_NAME,'') FROM kdbase..UUM_USER WHERE USER_CODE=@OP_ID

	  RETURN(@OP_NAME);
END


go

