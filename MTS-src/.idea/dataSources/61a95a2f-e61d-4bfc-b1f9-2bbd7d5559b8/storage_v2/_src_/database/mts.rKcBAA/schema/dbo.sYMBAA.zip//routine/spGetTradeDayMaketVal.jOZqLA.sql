CREATE  FUNCTION [dbo].[spGetTradeDayMaketVal] (@OP_ID               VARCHAR(20) , ---交易员代码 
                                                 @CUACCT_ID           VARCHAR(20) , ---资金代码 
                                                 @SYS_DATE            VARCHAR(8))    ---日期 
/*---------------------------------
功能:得到交易员在指定日期持仓市值

select dbo.spGetTradeDayMaketVal('6101004','','20181025')
 
-----------------------------*/

RETURNS NUMERIC(19,4) 

AS

BEGIN
 DECLARE @MaketVal  NUMERIC(19,4) 
   
   SET  @MaketVal=0   

   SELECT @MaketVal=ISNULL(SUM(HOLD_MAKET_VAL),0)
   FROM  T_TRADE_DAY_INFO
   WHERE (ISNULL(@OP_ID,'')='' OR OP_ID=@OP_ID)
       AND (ISNULL(@CUACCT_ID,'')='' OR CUACCT_ID=@CUACCT_ID)
       AND (ISNULL(@SYS_DATE,'')='' OR SYS_DATE=@SYS_DATE)
 

 
	  RETURN(@MaketVal);
END

go

