

--1. 创建处理函数  
CREATE FUNCTION [dbo].[KUI_GET_POST_NAMES](@id bigint)  
RETURNS varchar(8000)  
AS  
BEGIN  
    DECLARE @str varchar(8000)  
    SET @str = ''  
	SELECT @str = @str + ',' + UP.POST_NAME
  FROM  UUM_POST UP, UUM_OPER_POST P
 WHERE UP.POST_ID = P.POST_ID
   AND P.USER_CODE = @id
    RETURN STUFF(@str, 1, 1, '')  
END



go

