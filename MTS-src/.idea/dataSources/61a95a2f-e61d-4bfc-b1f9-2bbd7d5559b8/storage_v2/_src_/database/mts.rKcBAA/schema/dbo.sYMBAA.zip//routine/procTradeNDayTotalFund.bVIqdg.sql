CREATE PROC [dbo].[procTradeNDayTotalFund]    @OP_ID VARCHAR(8),
                                      @I Int               --天数
/*----------------------------------------------------------
功能：指定交易员指定天数内的总资产查询

exec procTradeNDayProfit '6101004', 5
 
*-----------------------------------------------------------*/
AS 
   SET NOCOUNT ON 
	 DECLARE @SQL_DECLARE VARCHAR(8000),@SQL_EXEC VARCHAR(8000),@SQL VARCHAR(8000),@DAY_SQL VARCHAR(8000)
	 SELECT @SQL_DECLARE='DECLARE ',
	        @SQL_EXEC='DECLARE @SQL VARCHAR(8000) SELECT  @SQL='''+'SELECT ' + @OP_ID +'AS OP_ID, ',
	        @DAY_SQL='SELECT  '
		
		WHILE @I>0
		BEGIN
		  SELECT @SQL_DECLARE=@SQL_DECLARE+'@PRO_DAY'+CONVERT(CHAR(2),@I)+' VARCHAR(8),'
		  SELECT @DAY_SQL=@DAY_SQL+'@PRO_DAY'+CONVERT(CHAR(2),@I)+'='+'dbo.spGetNoUDaySysDate(1,'+RTRIM(CONVERT(CHAR(2),@I))+'),'
		  
		  SELECT @SQL_EXEC=@SQL_EXEC+'ISNULL(dbo.spGetTradeDayProfit('+@OP_ID+','''+''''+''''+''''+','+''''+'+'+'@PRO_DAY'+RTRIM(CONVERT(CHAR(2),@I))+'+'+''''+'),0) ''+''[''+@PRO_DAY'+RTRIM(CONVERT(CHAR(2),@I))+'+'''+']'+','
		  SELECT @I=@I-1 
		END 
		 SELECT @SQL=left(@SQL_DECLARE,len(@SQL_DECLARE)-1)
		             + left(@DAY_SQL,len(@DAY_SQL)-1) 
					 + left(@SQL_EXEC,len(@SQL_EXEC)-1)+'''' 
					+ 'EXEC (@SQL)' 
		 EXEC(@SQL)
SET NOCOUNT ON
go

