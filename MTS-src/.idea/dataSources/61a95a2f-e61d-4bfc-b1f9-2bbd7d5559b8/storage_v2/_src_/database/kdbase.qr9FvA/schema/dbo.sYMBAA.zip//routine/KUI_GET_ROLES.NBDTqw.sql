
--1. 创建处理函数  
CREATE FUNCTION [dbo].[KUI_GET_ROLES](@id bigint)  
RETURNS varchar(8000)  
AS  
BEGIN  
    DECLARE @str varchar(8000)  
    SET @str = ''  
	SELECT @str = @str + ',' + UR.ROLE_NAME
  FROM UUM_USER_ROLE UUR, UUM_ROLE UR
 WHERE UUR.ROLE_ID = UR.ROLE_ID
   AND UUR.USER_CODE = @id
    RETURN STUFF(@str, 1, 1, '')  
END



go

