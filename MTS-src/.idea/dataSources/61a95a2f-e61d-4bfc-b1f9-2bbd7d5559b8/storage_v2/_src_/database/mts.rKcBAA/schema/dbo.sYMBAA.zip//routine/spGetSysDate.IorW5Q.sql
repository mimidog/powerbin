
CREATE  FUNCTION [dbo].[spGetSysDate]  (@SUBSYS_ID varchar(1))
/*---------------------------------
功能:得到系统交易日期

-----------------------------*/

RETURNS varchar(8) 

AS
BEGIN
  DECLARE  @SYSDATE varchar(8)
 SELECT @SYSDATE=SYSTEM_DATE
  FROM T_SYS_CONTROL


	  RETURN(@SYSDATE);
END
go

