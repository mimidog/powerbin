CREATE  FUNCTION [dbo].[spGetCALLOT_AMT] (@OP_ID           VARCHAR(20) , ---交易员代码
                                         @CUACCT_ID       VARCHAR(20) , ---资金代码
                                         @SYS_DATE        VARCHAR(8),   ---日期
										 @CALLOT_DIRECT   VARCHAR(1))   ---方向
/*---------------------------------
功能:得到交易员在指定日期转入转出金额

select dbo.spGetCALLOT_AMT('6102004','61020004','','3')


select *from T_TRADER_FUND_ASSET_LOG
-----------------------------*/

RETURNS NUMERIC(19,4) 

AS

BEGIN
 DECLARE @CALLOT_AMT  NUMERIC(19,4) 

 
set  @CALLOT_AMT=0   
  if @CALLOT_DIRECT='3'
  begin 
   SELECT @CALLOT_AMT=isnull(SUM(CASE WHEN CALLOT_DIRECT=2 THEN USE_AMOUNT ELSE 0 END)-SUM(CASE WHEN CALLOT_DIRECT=1 THEN USE_AMOUNT ELSE 0 END),0)
    FROM T_TRADER_FUND_ASSET_LOG
	WHERE  FLOW_TYPE='1'
	  AND CUACCT_ID=@CUACCT_ID
	  AND (isnull(@OP_ID,'')='' OR OP_ID=@OP_ID)
   end else begin 
      SELECT @CALLOT_AMT=isnull(SUM(USE_AMOUNT),0)
    FROM T_TRADER_FUND_ASSET_LOG
	WHERE  FLOW_TYPE='1'
	  AND CUACCT_ID=@CUACCT_ID 
	  AND (isnull(@OP_ID,'')='' OR OP_ID=@OP_ID)
	  AND CALLOT_DIRECT= @CALLOT_DIRECT
	  AND UP_DATE=@SYS_DATE

   end
	  RETURN(@CALLOT_AMT);
END

go

