

CREATE FUNCTION [dbo].[dic_trans] 
(	@PARAM  VARCHAR(4000))
/******
--把某一个(列)值，拆分开并转换后，用逗号拼接返回
--实现诸如下：输入  abcde   返回 A,B,C,D,E
 ******/
RETURNS VARCHAR(4000)
AS
BEGIN
  DECLARE  @RTN VARCHAR(4000);
  DECLARE @I INT;
  DECLARE @T CHAR(1);
  SELECT @I=LEN(@PARAM) 
  SET @RTN=''
  WHILE @I>0 
  BEGIN
    SET @T = SUBSTRING(@PARAM,@I,1);
    IF @T IS NOT NULL AND @T <>''  AND @T<>','
    BEGIN
      IF @I<>1 
        BEGIN
          --SELECT @RTN=CONCAT(@RTN,@T,',')
          SELECT @RTN=@RTN + @T + ','
        END
      ELSE
        BEGIN
          --SELECT @RTN=CONCAT(@RTN,@T)
          SELECT @RTN = @RTN + @T
        END    
    END
	SET @I=@I-1; 
  END
  RETURN @RTN;
END



go

