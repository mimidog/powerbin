CREATE function [dbo].[FN_SPLIT](@p_str varchar(max),@split varchar(2)) 
returns @t table(COLUMN_VALUE varchar(20)) 
as 
begin 

while(charindex(@split,@p_str)<>0) 
begin 
insert @t(COLUMN_VALUE) values (substring(@p_str,1,charindex(@split,@p_str)-1)) 
set @p_str = stuff(@p_str,1,charindex(@split,@p_str),'') 
end 
insert @t(COLUMN_VALUE) values (@p_str) 
return 
end

go

