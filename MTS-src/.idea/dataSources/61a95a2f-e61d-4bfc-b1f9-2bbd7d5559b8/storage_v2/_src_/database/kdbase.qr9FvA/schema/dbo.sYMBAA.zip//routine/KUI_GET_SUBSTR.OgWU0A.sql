-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[KUI_GET_SUBSTR]
--
(@P_STR   VARCHAR(8000), --要分割的字符串
 @P_SPLIT VARCHAR(30), --分隔符号
 @P_INDEX INT --取第几个元素
 ) 
 RETURNS VARCHAR(8000) AS
  

BEGIN
  DECLARE @T_P_STR    VARCHAR(8000) = RTRIM(LTRIM(@P_STR));
  DECLARE @T_LOCATION INT = CHARINDEX(@P_SPLIT, @T_P_STR);
  DECLARE @T_START    INT = 1;
  DECLARE @T_NEXT     INT = 1;
  DECLARE @T_SEED     INT = LEN(@P_SPLIT);
  DECLARE @V_RESULT   VARCHAR(8000);

  WHILE @T_LOCATION <> 0 AND @P_INDEX > @T_NEXT 
   BEGIN
    SET @T_START    = @T_LOCATION + @T_SEED;
    SET @T_LOCATION = CHARINDEX(@P_SPLIT, @T_P_STR, @T_START);
    SET @T_NEXT     = @T_NEXT + 1;
   END 

  IF @T_LOCATION = 0 
    SET @T_LOCATION = LEN(@T_P_STR) + 1;
;
  --这儿存在两种情况：1、字符串不存在分隔符号 2、字符串中存在分隔符号，跳出while循环后，t_location为0，那默认为字符串后边有一个分隔符号。

  SET @V_RESULT = SUBSTRING(@T_P_STR, @T_START, @T_LOCATION - @T_START);

  IF @V_RESULT IS NULL 
    SET @V_RESULT = '';

  RETURN @V_RESULT;
END


go

