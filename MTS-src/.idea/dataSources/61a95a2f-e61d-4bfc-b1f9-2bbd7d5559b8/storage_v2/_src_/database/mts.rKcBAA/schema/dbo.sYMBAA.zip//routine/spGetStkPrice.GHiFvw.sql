
CREATE FUNCTION [dbo].[spGetStkPrice] (@STK_ID VARCHAR(6))
  RETURNS NUMERIC(19,4) 
AS
/*---------------------------------
  说明：得到股票实时价格

-----------------------------*/
BEGIN
 DECLARE @STK_PRICE NUMERIC(19,4) 
  
  SET @STK_PRICE=0
select @STK_PRICE=isnull(max(stk_price),0)  from OPENQUERY(my, 'select * from t_stk_hq_t') where stk_id=@STK_ID
	  RETURN(@STK_PRICE);
END
go

