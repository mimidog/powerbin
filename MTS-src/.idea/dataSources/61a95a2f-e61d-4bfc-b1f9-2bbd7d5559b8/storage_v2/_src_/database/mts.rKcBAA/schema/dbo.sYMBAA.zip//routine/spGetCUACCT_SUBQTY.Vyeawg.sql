CREATE  FUNCTION [dbo].[spGetCUACCT_SUBQTY] ( @CUACCT_ID       VARCHAR(20) )   ---资金代码 
/*---------------------------------
功能:得到资金账户子账户数量
 
-----------------------------*/

RETURNS INT

AS

BEGIN
 DECLARE @SUBQTY INT

 
   SET  @SUBQTY=0   
    SELECT @SUBQTY=COUNT(*) FROM T_FUND_INFO_SUB WHERE CUACCT_ID=@CUACCT_ID

  RETURN(@SUBQTY);
END

go

